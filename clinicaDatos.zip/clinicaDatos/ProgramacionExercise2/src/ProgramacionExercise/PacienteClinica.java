/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProgramacionExercise;

import javax.swing.JOptionPane;

/**
 *
 * @author Nestor Luque
 */
public class PacienteClinica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        pac h = new pac();
        h.mostrar();
        
        JOptionPane.showMessageDialog(null ,"Fecha:  " + h.fecha+"\n"+"\n"+"nombre del paciente: " +h.nomPacient+"           Apellido del Paciente : " + h.apelliPaciente +"\n"+"Sexo: " +h.sexo+"         Edad:"+h.edad+"\n"+"ID: "+h.codigPaciente+"             Direccion: " + h.direccion+"\n"+"Nombre del Medico :  "+ h.nomMedico +"             Apellido del Medico:  " +h.apelliMedico+"\n"+"ID: "+h.codigMedico+"\n"+"\n"+"Nombre del centro medico : " + h.centroMedico +"\n"+"Motivo de consulta:  "+ h.motivConsult , "HISTORIAL MEDICO ",JOptionPane.INFORMATION_MESSAGE );
    }
    
}
