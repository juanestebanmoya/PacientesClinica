package ProgramacionExercise;
/**
 *
 * @author Juan Esteban Moya Riaño- Universidad de Cundinarmaca
 */
public class pac extends medi {
    String motivConsult;
    String fecha;
    String sexo;
    String direccion;
    int edad;
    //metodo sobrescrito
    @Override
    public void mostrar() {
        super.mostrar();
        edad=75;
        fecha ="Enero- 04- 2022";
        sexo ="Masculino";
        direccion="Madrid(cundinamarca)";
        motivConsult="Paciente masculino de 75 años de edad que acude al servicio del hospital Santa Ana por un cuadro caracterizado por un episodio \n"+
                    "de complejidad respiratoria, hematomas en los bloquias. dificultad para comer y hablar y fiebre constante (39.5), soltura y     \n"+
                    "malestar general con nauceas.\n" +
                    "15 dias atras el paciente presento episodios de complejidad respiratoria, soltura, y malestar en la traquea y tos con sangre la cual,\n"+
                    "afecto todo su organismo llevandolo al punto de desmauyarse y tener alucinaciones cronicas, el paciente presento muchas alteraciones \n"+
                    "nerviosas lo cual perjudica abrir su boca.\n" +
                    "produce mucho dolor en la espalda y alteraciones congenitas\n" +
                    "tiene fiebre, diarrea, constipación, dificultad respiratoria,alteracion motriz de sus articulaciones.\n" +
                    "Como antecedente el paciente hace muchos años presento alteraciones respiratorias, producidas por la bronquitis, y neumonia";
                
    }
}
