package ProgramacionExercise;
/**
 *
 * @author Juan Esteban Moya Riaño- Universidad de Cundinarmaca
 */
public class medi {
    String nomPacient;
    String apelliPaciente;
    String centroMedico;
    String nomMedico;
    String apelliMedico;
    int codigPaciente;
    int codigMedico;
    public void mostrar(){
        nomPacient="Juan Stiven ";
        apelliPaciente="Riaño Beltran";
        codigPaciente=66558882;
        nomMedico="Alberto Emilio";
        apelliMedico="Gonazles Servantes";
        centroMedico="San rafael(Bogota D.C)";
        codigMedico=58484563;
    }
    
}
